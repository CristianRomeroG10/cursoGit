import UIKit

let nombre = "Cristian"
let apellido = "Romero"

let saludo = "Hola \(nombre) \(apellido). ¿Cómo estas?"
print(saludo)

